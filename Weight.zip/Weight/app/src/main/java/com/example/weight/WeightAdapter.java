package com.example.weight;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private List<Entry> entries;
    private WeightDAO weightDAO;
    private Context context;

    public WeightAdapter(List<Entry> entries, WeightDAO weightDAO, Context context) {
        this.entries = entries;
        this.weightDAO = weightDAO;
        this.context = context;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_entry, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        Entry entry = entries.get(position);
        holder.textViewWeight.setText(String.valueOf(entry.getWeight()) + " kg");
        holder.textViewDate.setText(entry.getDate());

        holder.buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weightDAO.deleteWeightEntry(entry.getId());
                entries.remove(position);
                notifyItemRemoved(position); // Notify adapter about the removed item
                notifyItemRangeChanged(position, entries.size()); // Notify adapter about the range change
            }
        });

        holder.buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showUpdateWeightDialog(entry, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {

        TextView textViewWeight;
        TextView textViewDate;
        Button buttonDelete;
        Button buttonUpdate;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewWeight = itemView.findViewById(R.id.textViewWeight);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
            buttonUpdate = itemView.findViewById(R.id.buttonUpdate);
        }
    }

    private void showUpdateWeightDialog(Entry weightEntry, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Weight");

        final EditText input = new EditText(context);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(weightEntry.getWeight()));
        builder.setView(input);

        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String weightStr = input.getText().toString();
                if (!weightStr.isEmpty()) {
                    float weight = Float.parseFloat(weightStr);
                    weightDAO.updateWeightEntry(weightEntry.getId(), weightEntry.getDate(), weight);
                    weightEntry.setWeight(weight); // Update the weight in the entry
                    notifyItemChanged(position); // Notify adapter about the updated item
                } else {
                    Toast.makeText(context, "Please enter a weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }
}
