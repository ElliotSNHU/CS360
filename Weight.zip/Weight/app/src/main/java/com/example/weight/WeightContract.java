package com.example.weight;

import android.provider.BaseColumns;

public class WeightContract {

    public static abstract class WeightEntry implements BaseColumns {
        public static final String TABLE_NAME = "weight_entries";
        public static final String COLUMN_USERNAME = "username";
        public static final String COLUMN_WEIGHT = "weight";
        public static final String COLUMN_DATE = "date";
    }
}
