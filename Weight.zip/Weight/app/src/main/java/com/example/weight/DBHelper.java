package com.example.weight;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create user table
        String SQL_CREATE_USERS_TABLE = "CREATE TABLE " + UserContract.UserEntry.TABLE_NAME + " ("
                + UserContract.UserEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + UserContract.UserEntry.COLUMN_USERNAME + " TEXT NOT NULL, "
                + UserContract.UserEntry.COLUMN_PASSWORD + " TEXT NOT NULL);";

        // Create weight entries table
        String SQL_CREATE_WEIGHT_ENTRIES_TABLE = "CREATE TABLE " + WeightContract.WeightEntry.TABLE_NAME + " ("
                + WeightContract.WeightEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + WeightContract.WeightEntry.COLUMN_USERNAME + " TEXT NOT NULL, "
                + WeightContract.WeightEntry.COLUMN_WEIGHT + " REAL NOT NULL, "
                + WeightContract.WeightEntry.COLUMN_DATE + " TEXT NOT NULL);";

        db.execSQL(SQL_CREATE_USERS_TABLE);
        db.execSQL(SQL_CREATE_WEIGHT_ENTRIES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrade if needed
        db.execSQL("DROP TABLE IF EXISTS " + UserContract.UserEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + WeightContract.WeightEntry.TABLE_NAME);
        onCreate(db);
    }
}
