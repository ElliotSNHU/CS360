package com.example.weight;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSNotificationActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 1;
    private TextView textViewPermissionStatus;
    private Button buttonRequestPermission;
    private Button buttonSendNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        textViewPermissionStatus = findViewById(R.id.textViewPermissionStatus);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSendNotification = findViewById(R.id.buttonSendNotification);

        checkSMSPermission();

        buttonRequestPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSMSPermission();
            }
        });

        buttonSendNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSMSNotification();
            }
        });
    }

    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            textViewPermissionStatus.setText("SMS Permission: Denied");
            buttonRequestPermission.setVisibility(View.VISIBLE);
        } else {
            textViewPermissionStatus.setText("SMS Permission: Granted");
            buttonSendNotification.setVisibility(View.VISIBLE);
        }
    }

    private void requestSMSPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
    }

    private void sendSMSNotification() {
        String phoneNumber = "1234567890"; // Replace with a valid phone number
        String message = "This is a test SMS notification.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Notification sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send notification.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textViewPermissionStatus.setText("SMS Permission: Granted");
                buttonSendNotification.setVisibility(View.VISIBLE);
                buttonRequestPermission.setVisibility(View.GONE);
            } else {
                textViewPermissionStatus.setText("SMS Permission: Denied");
                buttonRequestPermission.setVisibility(View.VISIBLE);
                buttonSendNotification.setVisibility(View.GONE);
            }
        }
    }
}
