package com.example.weight;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class WeightDAO {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    private String[] allColumns = {
            DatabaseHelper.COLUMN_ID,
            DatabaseHelper.COLUMN_DATE,
            DatabaseHelper.COLUMN_WEIGHT
    };

    public WeightDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void addWeightEntry(String date, float weight) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_DATE, date);
        values.put(DatabaseHelper.COLUMN_WEIGHT, weight);

        database.insert(DatabaseHelper.TABLE_WEIGHTS, null, values);
    }

    public void deleteWeightEntry(long id) {
        database.delete(DatabaseHelper.TABLE_WEIGHTS, DatabaseHelper.COLUMN_ID + " = " + id, null);
    }

    public void updateWeightEntry(long id, String date, float weight) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_DATE, date);
        values.put(DatabaseHelper.COLUMN_WEIGHT, weight);

        database.update(DatabaseHelper.TABLE_WEIGHTS, values, DatabaseHelper.COLUMN_ID + " = " + id, null);
    }

    public List<Entry> getAllWeightEntries() {
        List<Entry> weightEntries = new ArrayList<>();

        Cursor cursor = database.query(DatabaseHelper.TABLE_WEIGHTS, allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Entry weightEntry = cursorToWeightEntry(cursor);
            weightEntries.add(weightEntry);
            cursor.moveToNext();
        }
        cursor.close();
        return weightEntries;
    }

    private Entry cursorToWeightEntry(Cursor cursor) {
        Entry weightEntry = new Entry();
        weightEntry.setId(cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID)));
        weightEntry.setDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE)));
        weightEntry.setWeight(cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT)));
        return weightEntry;
    }

    public long getLastInsertedId() {
        Cursor cursor = database.rawQuery("SELECT last_insert_rowid()", null);
        long lastId = -1;
        if (cursor.moveToFirst()) {
            lastId = cursor.getLong(0);
        }
        cursor.close();
        return lastId;
    }
}
