package com.example.weight;

import android.Manifest;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class GridDisplayActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "GoalWeightPrefs";
    private static final String KEY_GOAL_WEIGHT = "goal_weight";
    private static final int REQUEST_SMS_PERMISSION = 123;

    private TextView textViewCurrentGoalWeight;
    private RecyclerView recyclerViewData;
    private WeightAdapter adapter;
    private List<Entry> entries;
    private WeightDAO weightDAO;
    private float goalWeight = -1; // Default value to indicate no goal weight set

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_display);

        textViewCurrentGoalWeight = findViewById(R.id.textViewCurrentGoalWeight);
        recyclerViewData = findViewById(R.id.recyclerViewData);
        EditText editTextWeight = findViewById(R.id.editTextWeight);
        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);
        Button buttonSetGoalWeight = findViewById(R.id.buttonSetGoalWeight);

        weightDAO = new WeightDAO(this);
        weightDAO.open();
        entries = weightDAO.getAllWeightEntries();
        adapter = new WeightAdapter(entries, weightDAO, this);
        recyclerViewData.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewData.setAdapter(adapter);

        checkSmsPermission();

        // Load the goal weight from SharedPreferences
        loadGoalWeight();

        buttonAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightStr = editTextWeight.getText().toString();
                if (!weightStr.isEmpty()) {
                    float weight = Float.parseFloat(weightStr);
                    String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                    weightDAO.addWeightEntry(date, weight);
                    long lastInsertedId = weightDAO.getLastInsertedId();
                    entries.add(new Entry(lastInsertedId, date, weight)); // Add new entry to the list with correct ID
                    adapter.notifyItemInserted(entries.size() - 1); // Notify adapter about the new item
                    editTextWeight.setText("");

                    // Check if the weight is less than the goal weight and send an SMS
                    if (goalWeight > 0 && weight <= goalWeight) {
                        sendCongratsSms();
                    }
                } else {
                    Toast.makeText(GridDisplayActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonSetGoalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSetGoalWeightDialog();
            }
        });

        updateGoalWeightText();
    }

    @Override
    protected void onDestroy() {
        weightDAO.close();
        super.onDestroy();
    }

    private void showSetGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Set", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String goalWeightStr = input.getText().toString();
                if (!goalWeightStr.isEmpty()) {
                    goalWeight = Float.parseFloat(goalWeightStr);
                    saveGoalWeight(goalWeight);
                    updateGoalWeightText();
                } else {
                    Toast.makeText(GridDisplayActivity.this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void updateGoalWeightText() {
        if (goalWeight > 0) {
            textViewCurrentGoalWeight.setText(String.valueOf(goalWeight) + " kg");
        } else {
            textViewCurrentGoalWeight.setText("Not Set");
        }
    }

    private void saveGoalWeight(float goalWeight) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat(KEY_GOAL_WEIGHT, goalWeight);
        editor.apply();
    }

    private void loadGoalWeight() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        goalWeight = sharedPreferences.getFloat(KEY_GOAL_WEIGHT, -1);
    }

    private void checkSmsPermission() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendCongratsSms() {
        String phoneNumber = "+15551234567"; // Replace with the actual phone number
        String message = "Congrats! You have met your goal weight.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Congrats message sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}
